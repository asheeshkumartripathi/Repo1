package com.util;

public class TestUtil {
	
	public static long Page_Load_Timeout=15;
	public static long Implicit_Wait=10;
	

}
